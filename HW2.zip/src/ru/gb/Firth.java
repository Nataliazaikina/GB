package ru.gb;

//* Написать метод, который определяет, является ли год високосным,
// и возвращает boolean (високосный - true, не високосный - false).
// Каждый 4-й год является високосным, кроме каждого 100-го,
// при этом каждый 400-й – високосный.

public class Firth {
    public static void main(String[] args) {

        boolean result = isVisokos(1123);
        System.out.println(result);
    }

    public static boolean isVisokos(int year) {
        if ((year % 4 == 0) && (year % 100 != 0)) {
            return true;
        }
        if ((year % 100 == 0) && (year % 400 == 0)) {
            return true;
        }
        return false;
    }
}