package ru.gb;

// Написать метод, которому в качестве параметра передается целое число.
// Метод должен вернуть true, если число отрицательное, и вернуть false если положительное.


public class Third {
    public static void main(String[] args) {

        boolean a = isNegative(-10);
        System.out.println(a);
    }

    public static boolean isNegative(int x) {
        if (x >= 0) {
            return true;
        }
        return false;
    }
}
