package ru.gb;

// Написать метод, которому в качестве аргументов передается строка и число,
// метод должен отпечатать в консоль указанную строку, указанное количество раз;

import javax.swing.*;

public class Forth {
    public static void main(String[] args) {

        printWordNTimes("hello", 5);
    }

    public static void printWordNTimes(String word, int times) {
        for (int i = 0; i < times; i++) {
            System.out.println(word);
        }
    }



}

