package ru.gb;

public class First {

    public static void main(String[] args) {

        within10and20(10, 13);
        System.out.println(result);
    }
    static boolean result;
    public static boolean within10and20(int x1, int x2) {

        if ((x1 + x2) >= 10 && (x1 + x2) <= 20) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }
}
