package ru.gb;

//Написать метод, которому в качестве параметра передается целое число,
// метод должен напечатать в консоль, положительное ли число передали или отрицательное.
// Замечание: ноль считаем положительным числом.

public class Second {

    public static void main(String[] args) {
        isPositiveOrNegative(-10);
    }

    public static void isPositiveOrNegative(int x) {
        if (x >= 0) {
            System.out.println("x is positive number");
        } else {
            System.out.println("x is negative number");
        }
    }
}
