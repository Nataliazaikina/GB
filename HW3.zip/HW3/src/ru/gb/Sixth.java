package ru.gb;

// * Задать одномерный массив и найти в нем минимальный и максимальный элементы ;

import java.util.Arrays;

public class Sixth {
    public static void main(String[] args) {
        int[] arr = {12, 87, 3, 7, 0, 4};
        Arrays.sort(arr);
        int min = arr[0];
        int max = arr[arr.length-1];
        System.out.println("Минимальное значение: " + min);
        System.out.println("Максимальное значение: " + max);
        //System.out.println(Arrays.toString(arr));
    }

}
