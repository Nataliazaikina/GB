package ru.gb;

import java.util.Arrays;

public class Firth {
    public static void main(String[] args) {

        createArray(5, 15);

    }

    //public static int[] array = new int[];
    public static void createArray(int len, int initialValue){

        int[] arr = new int[len];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = initialValue;
        }
        System.out.println(Arrays.toString(arr));
    }
}
