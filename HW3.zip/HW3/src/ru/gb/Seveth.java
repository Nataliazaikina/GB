package ru.gb;

// ** Написать метод, в который передается не пустой одномерный целочисленный массив,
// метод должен вернуть true, если в массиве есть место, в котором сумма левой и правой части массива равны.
//Примеры:
//checkBalance([2, 2, 2, 1, 2, 2, ||| 10, 1]) → true, т.е. 2 + 2 + 2 + 1 + 2 + 2 = 10 + 1
//checkBalance([1, 1, 1, ||| 2, 1]) → true, т.е. 1 + 1 + 1 = 2 + 1
//
//граница показана символами |||, эти символы в массив не входят и не имеют никакого отношения к ИЛИ.


public class Seveth {
    public static void main(String[] args) {


        int[] arr = {1, 5, 9, 4, 11, 8, 3};
        boolean result = checkBalance(arr);
        System.out.println(result);
    }


    public static boolean checkBalance(int[] arr) {
        int sum = 0;
        int sum1 = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        if (sum % 2 != 0) {
            return false;
        }

        for (int i = 0; i < arr.length; i++) {
            while (sum1 < sum/2) {
                sum1 += arr[i];
                if(sum1 == sum/2) {
                    return true;
                }
            }
        }
        return false;
    }
}
