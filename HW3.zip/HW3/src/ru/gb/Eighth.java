package ru.gb;

// *** Написать метод, которому на вход подается одномерный массив и число n (может быть положительным,
// или отрицательным), при этом метод должен сместить все элементы массива на n позиций.
// Элементы смещаются циклично. Для усложнения задачи нельзя пользоваться вспомогательными массивами.
// Примеры: [ 1, 2, 3 ] при n = 1 (на один вправо) -> [ 3, 1, 2 ]; [ 3, 5, 6, 1]
// при n = -2 (на два влево) -> [ 6, 1, 3, 5 ]. При каком n в какую сторону сдвиг можете выбирать сами.


import java.util.Arrays;

public class Eighth {


    public static void main(String[] args) {

        int[] arr = {3, 7, 9, 0, 4};
        changeArray(arr, 2);
    }

    public static void changeArray(int[] arr, int n) {
        int[] arrCopy = arr;

        for (int i = 0; i < arr.length; i++) {
            if ((i + n) < arr.length) {
                arrCopy[i + n] = arr[i];
            }
            if ((i + n) >= arr.length) {
                arrCopy[i + n - arr.length] = arr[i];
            }
        }
        System.out.println(Arrays.toString(arrCopy));
    }


}
