package ru.gb;

import java.util.Arrays;

public class First {
    public static void main(String[] args) {
        int[] arr = {1, 0, 1, 0, 0, 0, 1, 1};


        for (int i: arr) {
            arr[i] = (arr[i]==0)?0:1;

        }

        System.out.print(Arrays.toString(arr));


    }
}
