package ru.gb.CounterApp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CounterApp extends JFrame {


    private int value;
    private boolean isTrue = false;
    private int savedValue;

    public CounterApp(int initialValue) {
        value = initialValue;
        setBounds(300, 200, 500, 300);
        setTitle("Simple Counter");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        Font font = new Font("Arial", Font.BOLD, 32);

        JLabel counterValueView = new JLabel();
        counterValueView.setFont(font);
        counterValueView.setHorizontalAlignment(SwingConstants.CENTER);
        add(counterValueView, BorderLayout.CENTER);

        counterValueView.setText(String.valueOf(value));

        JButton decrementButton = new JButton("<");
        decrementButton.setFont(font);
        add(decrementButton, BorderLayout.WEST);

        JButton incrementButton = new JButton(">");
        incrementButton.setFont(font);
        add(incrementButton, BorderLayout.EAST);

        Font fontText = new Font("Arial", Font.PLAIN,24);

        JButton zeroButton = new JButton("Обнулить значение");
        zeroButton.setFont(fontText);
        add(zeroButton, BorderLayout.SOUTH);

        JButton saveCount = new JButton("Сохранить/добавить значение");
        saveCount.setFont(fontText);
        add(saveCount, BorderLayout.NORTH);

        decrementButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                value--;
                counterValueView.setText(String.valueOf(value));
            }
        });

        incrementButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                value++;
                counterValueView.setText(String.valueOf(value));
            }
        });

        zeroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                value = 0;
                counterValueView.setText(String.valueOf(value));
            }
        });

        saveCount.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isTrue) {
                    counterValueView.setText(String.valueOf(savedValue));
                    value = savedValue;
                    isTrue = false;
                } else {
                    savedValue = value;
                    isTrue = true;
                }
            }
        });

        setVisible(true);

    }

    public static void main(String[] args) {
        new CounterApp(0);
    }
}
