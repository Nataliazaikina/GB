package ru.gb.XO;

import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.util.Scanner;

public class Main extends JFrame {
    public static char[][] map;
    public static final int SIZE = 3;
    public static final int DOTS_TO_WIN = 3;
    public static final char DOT_EMPTY = '•';
    public static final char DOT_X = 'X';
    public static final char DOT_O = 'O';

    public Main() {
        setBounds(200, 300, 500,500);
        setTitle("Игра в крестики-нолики");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 4));

        Font font = new Font("Arial", Font.BOLD, 24);
        JButton button1 = new JButton("№№");
        JButton button2 = new JButton("1");
        JButton button3 = new JButton("2");
        JButton button4 = new JButton("3");
        JButton button5 = new JButton("1");
        JButton button6 = new JButton(" ");
        JButton button7 = new JButton(" ");
        JButton button8 = new JButton(" ");
        JButton button9 = new JButton("2");
        JButton button10 = new JButton(" ");
        JButton button11 = new JButton(" ");
        JButton button12 = new JButton(" ");
        JButton button13 = new JButton("3");
        JButton button14 = new JButton(" ");
        JButton button15 = new JButton(" ");
        JButton button16 = new JButton(" ");

        button1.setFont(font);
        button2.setFont(font);
        button3.setFont(font);
        button4.setFont(font);
        button5.setFont(font);
        button6.setFont(font);
        button7.setFont(font);
        button8.setFont(font);
        button9.setFont(font);
        button10.setFont(font);
        button11.setFont(font);
        button12.setFont(font);
        button13.setFont(font);
        button14.setFont(font);
        button15.setFont(font);
        button16.setFont(font);

        add(button1);
        add(button2);
        add(button3);
        add(button4);
        add(button5);
        add(button6);
        add(button7);
        add(button8);
        add(button9);
        add(button10);
        add(button11);
        add(button12);
        add(button13);
        add(button14);
        add(button15);
        add(button16);







        setVisible(true);
    }

    public static void main(String[] args) {

        new Main();
//        initMap();
//
//
//        printMap();
//        while (true) {
//            humanTurn();
//            printMap();
//            if (checkWinH(DOT_X) || checkWinV(DOT_X) || checkWinD1(DOT_X) || checkWinD2(DOT_X)) {
//                System.out.println("Победил человек");
//                break;
//            }
//            if (isMapFull()) {
//                System.out.println("Ничья");
//                break;
//            }
//            aiTurn();
//            printMap();
//            if (checkWinH(DOT_O) || checkWinV(DOT_O) || checkWinD1(DOT_O) || checkWinD2(DOT_O)) {
//                System.out.println("Победил Искуственный Интеллект");
//                break;
//            }
//            if (isMapFull()) {
//                System.out.println("Ничья");
//                break;
//            }
//        }
//    }
//
//    public static void initMap() {
//        map = new char[SIZE][SIZE];
//        for (int i = 0; i < SIZE; i++) {
//            for (int j = 0; j < SIZE; j++) {
//                map[i][j] = DOT_EMPTY;
//            }
//        }
//    }
//
//    public static void printMap() {
//        for (int i = 0; i <= SIZE; i++) {
//            System.out.print(i + " ");
//        }
//        System.out.println();
//        for (int i = 0; i < SIZE; i++) {
//            System.out.print((i + 1) + " ");
//            for (int j = 0; j < SIZE; j++) {
//                System.out.print(map[i][j] + " ");
//            }
//            System.out.println();
//        }
//        System.out.println();
//    }
//
//    public static Scanner sc = new Scanner(System.in);
//    public static void humanTurn() {
//        int x, y;
//        do {
//            System.out.println("Введите координаты в формате X Y");
//            x = sc.nextInt() - 1;
//            y = sc.nextInt() - 1;
//        } while (!isCellValid(x, y));
//        map[y][x] = DOT_X;
//    }
//
//    public static boolean isCellValid(int x, int y) {
//        if (x < 0 || x >= SIZE || y < 0 || y >= SIZE) return false;
//        if (map[y][x] == DOT_EMPTY) return true;
//        return false;
//    }
//
//    public static Random rand = new Random();
//    public static void aiTurn() {
//        int x, y;
//        do {
//            x = rand.nextInt(SIZE);
//            y = rand.nextInt(SIZE);
//        } while (!isCellValid(x, y));
//        System.out.println("Компьютер походил в точку " + (x + 1) + " " + (y + 1));
//        map[y][x] = DOT_O;
//    }
//
//    public static boolean checkWinH(char symb) {
//
//
//        for (int i = 0; i < SIZE; i++) {
//            int SIZEJ = 0;
//            for (int j = 0; j < SIZE; j++) {
//                if (map[i][j] == symb) {
//                    SIZEJ += 1;
//                    if (SIZEJ == 3) {
//                        return true;
//                    }
//                }
//            }
//        }
//        return false;
//    }
//
//    public static boolean checkWinV(char symb) {
//
//        for (int i = 0; i < SIZE; i++) {
//            int SIZEJ = 0;
//            for (int j = 0; j < SIZE; j++) {
//                if (map[j][i] == symb) {
//                    SIZEJ += 1;
//                    if (SIZEJ == 3) {
//                        return true;
//                    }
//                }
//            }
//        }
//        return false;
//    }
//
//    public static boolean checkWinD1(char symb) {
//
//        for (int i = 0; i < SIZE; i++) {
//            int SIZEJ = 0;
//            for (int j = (SIZE - 1); j >= 0; j--) {
//                if (map[i][j] == symb) {
//                    SIZEJ += 1;
//                    if (SIZEJ == 3) {
//                        return true;
//                    }
//                }
//            }
//        }
//        return false;
//    }
//
//    public static boolean checkWinD2(char symb) {
//
//        for (int i = (SIZE - 1); i >= 0; i--) {
//            int SIZEJ = 0;
//            for (int j = 0; j < SIZE; j++) {
//                if (map[j][i] == symb) {
//                    SIZEJ += 1;
//                    if (SIZEJ == 3) {
//                        return true;
//                    }
//                }
//            }
//        }
//        return false;
//    }
//
//    public static boolean isMapFull() {
//        for (int i = 0; i < SIZE; i++) {
//            for (int j = 0; j < SIZE; j++) {
//                if (map[i][j] == DOT_EMPTY) return false;
//            }
//        }
//        return true;
//    }
    }
}
