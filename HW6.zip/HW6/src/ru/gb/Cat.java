package ru.gb;

public class Cat extends Animals {

    public Cat(String name) {
        super(name);
    }


    public void create() {
        System.out.println(this.name);
    }

    @Override
    public void swim(int length) {
        System.out.println("Кот не умеет плавать.");
    }

    @Override
    public void run (int length) {
        if (length <= 200) {
            System.out.println("Кот пробежал " + length + " метров.");
        } else {
            System.out.println("Кот бежал с максимальной скоростью.");
        }

    }
}
