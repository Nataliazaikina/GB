package ru.gb;

public class Animals {
    String name;

    public Animals(String name){
        this.name = name;
    }

    public static void main(String[] args) {

        int countAnimal = 0;
        int countCat = 0;
        int countDog = 0;
        int quantity = (int)(Math.random() * 150);
        for (int i = 0; i < quantity; i++) {

            int typeAnimal = (int)(Math.random() * 30);
            switch (typeAnimal){
                case 1:
                    Animals animals = new Animals("Животное" + i);
                    animals.create();
                    animals.swim((int)(Math.random() * 700));
                    animals.run((int)(Math.random() * 700));
                    countAnimal++;
                case 2:
                    Cat cat = new Cat("Кошка" + i);
                    cat.create();
                    cat.swim((int)(Math.random() * 700));
                    cat.run((int)(Math.random() * 700));
                    countCat++;
                case 3:
                    Dog dog = new Dog("Собака" + i);
                    dog.create();
                    dog.swim((int)(Math.random() * 700));
                    dog.run((int)(Math.random() * 700));
                    countDog++;
            }
        }
        System.out.println("Были созданы: " + countAnimal + " животных, " + countCat + " кошек, " + countDog + " собак.");
    }

    public void create() {
        System.out.println(this.name);
    }

    public void swim(int length) {
        System.out.println("Животное проплыло " + length + " метров.");
    }

    public void run(int length) {
        System.out.println("Животное пробежало " + length + " метров.");
    }

}
