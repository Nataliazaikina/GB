package ru.gb;

public class Dog extends Animals {

    public Dog(String name) {
        super(name);
    }


    public void create() {
        System.out.println(this.name);
    }

    @Override
    public void swim (int length) {
        if (length >= 10) {
            System.out.println("Собака плыла с максимальной скоростью.");
        } else {
            System.out.println("Собака проплыла " + length + " метров.");
        }
    }
    public void run (int length) {
        if (length <= 500) {
            System.out.println("Собака пробежала " + length + " метров.");
        } else {
            System.out.println("Собака бежала с максимальной скоростью.");
        }
    }


}
