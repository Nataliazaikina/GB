package ru.gb;

public class Employee {
    String FirstSecondName;
    String position;
    String email;
    String telephone;
    int salary;
    byte age;

    public Employee(String FirstSecondName, String position, String email, String telephone, int salary, byte age) {
        this.FirstSecondName = FirstSecondName;
        this.position = position;
        this.email = email;
        this.telephone = telephone;
        this.salary = salary;
        this.age = age;
    }

    public void info() {
        System.out.println("Меня зовут " + FirstSecondName + ". Я работаю " + position +
                ". My salary is " + salary + ". My age is " + ". My email is" + email + ". My phone is " + telephone);
    }
}
