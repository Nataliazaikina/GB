package ru.gb;

import java.util.Arrays;

public class Main {

    public static Employee[] EmpArray = new Employee[5];

    public static void main(String[] args) {


        EmpArray[0] = new Employee("Ivanov Semen", "doctor", "mn@yandex.ru",
                "+79045670987", 50000, (byte) 24);
        EmpArray[1] = new Employee("Smirnov Petr", "teacher", "mfdgn@yandex.ru",
                "+79045614987", 70000, (byte) 27);
        EmpArray[2] = new Employee("Aleksandrov Ivan", "doctor", "mn@yandex.ru",
                "+79045670987", 100000, (byte) 45);
        EmpArray[3] = new Employee("Vasilyev Semen", "doctor", "mn@yandex.ru",
                "+79045670987", 150000, (byte) 54);
        EmpArray[4] = new Employee("Pushkin Denis", "doctor", "mn@yandex.ru",
                "+79045670987", 150000, (byte) 32);

        for (Employee s: EmpArray) {
            if (s.age > 40) {
                System.out.println("Сотрудник старше 40 лет: " + s.FirstSecondName + ", должность: " + s.position + ", Email: " + s.email +
                        ", возраст: " + s.age + ", телефон: " + s.telephone + ", зарплата: " + s.salary + " рублей");
            }
        }

    }

}
