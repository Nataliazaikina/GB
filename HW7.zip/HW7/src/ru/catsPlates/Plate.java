package ru.catsPlates;

public class Plate {
    private int food;

    public Plate(int food) {
        this.food = food;
    }

    public void decreaseFood(int amount) {
        food -= amount;
        if(food < 0) {
            food = 0;
        }
    }

    public void info() {
        System.out.println("Food amount: " + food);
    }

    public int getFood() {
        return food;
    }

    public void setFood(int food) {
        this.food = food;
    }

    public void setAddFood(int addition) {
        this.food += addition;
    }
}
//        plate.setFood(plate.getFood() - cat.getAppetite());