package ru.catsPlates;

public class MainClass {

    public static void main(String[] args) {
        int quantity  = (int)(Math.random() * 15);
        Plate plate = new Plate(10);
        for (int i = 1; i < quantity; i++) {
            int appetite = (int)(Math.random() * 7);
            boolean satiety = false;
            Cat cat = new Cat("Cat" + i, appetite, satiety);
            cat.setName("Cat" + i);
            System.out.println(cat.getName());
            System.out.println("Аппетит кота: " + cat.getAppetite());
            plate.info();

            if (cat.getAppetite() < plate.getFood()){
                satiety = true;
            }
            if(cat.getAppetite() <= plate.getFood()) {
                cat.eat(plate);
                System.out.println("Кот съел " + cat.getAppetite() + " порции еды");
            } else {
                System.out.println("Коту не хватило еды.");
            }

            cat.setSatiety(satiety);
            System.out.println("Сытость кота" + i + ": " + satiety);

            plate.setAddFood(1);
            System.out.println("В тарелку добавили порцию еды");

            plate.info();
            System.out.println();


        }


    }
}


